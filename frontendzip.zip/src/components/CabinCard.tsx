import React from 'react';
import { MapPin, Users, Building2, ChevronRight, Wifi, Monitor, Coffee ,Activity} from 'lucide-react';
import { Cabin } from '../types';

interface CabinCardProps {
  cabin: Cabin;
  onEdit?: (cabin: Cabin) => void;
  onBookNow?: (cabin: Cabin) => void;
  userRole: 'ADMIN' | 'EMPLOYEE';
}

export default function CabinCard({ cabin, onBookNow, userRole }: CabinCardProps) {
  
  // Icon mapping for common amenities
  const getAmenityIcon = (name: string) => {
    const n = name.toLowerCase();
    if (n.includes('wifi')) return <Wifi size={12} />;
    if (n.includes('monitor') || n.includes('tv')) return <Monitor size={12} />;
    if (n.includes('coffee')) return <Coffee size={12} />;
    return null;
  };

  return (
    <div className="premium-card overflow-hidden group">
      {/* Decorative top bar based on status */}
      <div className={`h-1.5 w-full ${cabin.status === 'AVAILABLE' ? 'bg-emerald-500' : 'bg-slate-300'}`} />
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="p-3 bg-slate-50 rounded-2xl text-slate-400 group-hover:bg-emerald-50 group-hover:text-emerald-500 transition-colors duration-300">
            <Building2 size={24} />
          </div>
          <div className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter border ${
            cabin.status === 'AVAILABLE' 
              ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
              : 'bg-slate-50 text-slate-400 border-slate-200'
          }`}>
            {cabin.status}
          </div>
        </div>

        <h3 className="text-xl font-black text-slate-800 leading-tight mb-1">{cabin.cabinName}</h3>
        <div className="flex items-center gap-2 text-slate-400 font-bold text-[11px] uppercase tracking-wider mb-6">
          <MapPin size={12} className="text-emerald-500" />
          {cabin.location} • Floor {cabin.floor}
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100">
            <div className="flex items-center gap-1.5 text-slate-400 mb-1">
              <Users size={12} />
              <span className="text-[10px] font-bold uppercase">Capacity</span>
            </div>
            <p className="text-sm font-black text-slate-700">{cabin.capacity} Seats</p>
          </div>
          
          <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 overflow-hidden">
            <div className="flex items-center gap-1.5 text-slate-400 mb-1">
              <Activity size={12} />
              <span className="text-[10px] font-bold uppercase">Amenities</span>
            </div>
            <div className="flex gap-1.5 items-center">
              {cabin.amenities.slice(0, 3).map((a, i) => (
                <div key={i} title={a} className="text-slate-600 hover:text-emerald-500 transition-colors">
                  {getAmenityIcon(a) || <div className="h-1 w-1 bg-slate-300 rounded-full" />}
                </div>
              ))}
              {cabin.amenities.length > 3 && <span className="text-[9px] font-bold text-slate-400">+{cabin.amenities.length - 3}</span>}
            </div>
          </div>
        </div>

        {userRole === 'EMPLOYEE' ? (
          <button
            disabled={cabin.status !== 'AVAILABLE'}
            onClick={() => onBookNow?.(cabin)}
            className={`
              w-full py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2
              ${cabin.status === 'AVAILABLE' 
                ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 hover:bg-emerald-600 hover:-translate-y-0.5 active:translate-y-0" 
                : "bg-slate-100 text-slate-400 cursor-not-allowed"}
            `}
          >
            {cabin.status === 'AVAILABLE' ? (
              <>Reserve Now <ChevronRight size={14} /></>
            ) : "Unavailable"}
          </button>
        ) : (
          <button className="w-full py-3 bg-white border-2 border-slate-100 rounded-2xl text-slate-600 font-bold text-xs uppercase tracking-widest hover:border-emerald-500 hover:text-emerald-600 transition-all">
            Manage Cabin
          </button>
        )}
      </div>
    </div>
  );
}
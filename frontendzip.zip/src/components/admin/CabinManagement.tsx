// import { useEffect, useState } from "react";
// import toast from "react-hot-toast";
// import {
//   Edit,
//   RefreshCcw,
//   Save,
//   X
// } from "lucide-react";

// import {
//   getCabins,
//   updateCabin,
// } from "../../services/api";

// import {
//   Cabin,
//   UpdateCabinRequest,
// } from "../../types";

// export default function CabinManagement() {

//   const [loading, setLoading] = useState(true);

//   const [cabins, setCabins] = useState<Cabin[]>([]);

//   const [selectedCabin, setSelectedCabin] =
//     useState<Cabin | null>(null);

//   const [open, setOpen] = useState(false);

//   const [form, setForm] =
//     useState<UpdateCabinRequest>({
//       cabinName: "",
//       floor: 1,
//       capacity: 1,
//       location: "",
//       amenities: [],
//       status: "AVAILABLE",
//       active: true,
//     });

//   const loadCabins = async () => {

//     try {

//       setLoading(true);

//       const response =
//         await getCabins();

//       setCabins(response.data.data);

//     } catch (err: any) {

//       toast.error(
//         err?.response?.data?.message ??
//         "Unable to load cabins."
//       );

//     } finally {

//       setLoading(false);

//     }

//   };

//   useEffect(() => {

//     loadCabins();

//   }, []);

//   const handleEdit = (
//     cabin: Cabin
//   ) => {

//     setSelectedCabin(cabin);

//     setForm({

//       cabinName: cabin.cabinName,

//       floor: cabin.floor,

//       capacity: cabin.capacity,

//       location: cabin.location,

//       amenities: cabin.amenities,

//       status: cabin.status,

//       active: cabin.active,

//     });

//     setOpen(true);

//   };

//   const handleUpdate = async () => {

//     if (!selectedCabin) return;

//     try {

//       await updateCabin(
//         selectedCabin.id,
//         form
//       );

//       toast.success(
//         "Cabin Updated Successfully"
//       );

//       setOpen(false);

//       loadCabins();

//     } catch (err: any) {

//       toast.error(
//         err?.response?.data?.message ??
//         "Unable to update cabin."
//       );

//     }

//   };

//   if (loading) {

//     return (

//       <div className="flex justify-center items-center h-[60vh]">

//         <div className="text-lg font-semibold text-slate-500">

//           Loading Cabins...

//         </div>

//       </div>

//     );

//   }

//   return (

//     <div className="bg-white rounded-2xl shadow border border-slate-200">

//       <div className="p-6 border-b flex justify-between items-center">

//         <div>

//           <h1 className="text-2xl font-bold">

//             Cabin Management

//           </h1>

//           <p className="text-slate-500 mt-1">

//             Manage all cabins.

//           </p>

//         </div>

//         <button
//           onClick={loadCabins}
//           className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-xl flex items-center gap-2"
//         >

//           <RefreshCcw size={18} />

//           Refresh

//         </button>

//       </div>

//       <div className="overflow-x-auto">

//         <table>

//           <thead>

//             <tr>

//               <th>Cabin</th>

//               <th>Floor</th>

//               <th>Capacity</th>

//               <th>Status</th>

//               <th>Active</th>

//               <th>Location</th>

//               <th>Actions</th>

//             </tr>

//           </thead>

//           <tbody>
//                       {cabins.length === 0 ? (

//             <tr>

//               <td
//                 colSpan={7}
//                 className="text-center py-12 text-slate-500"
//               >

//                 No Cabins Found

//               </td>

//             </tr>

//           ) : (

//             cabins.map((cabin) => (

//               <tr key={cabin.id}>

//                 <td className="font-semibold">

//                   {cabin.cabinName}

//                 </td>

//                 <td>

//                   {cabin.floor}

//                 </td>

//                 <td>

//                   {cabin.capacity}

//                 </td>

//                 <td>

//                   <span
//                     className={`px-3 py-1 rounded-full text-xs font-semibold

//                     ${
//                       cabin.status === "AVAILABLE"
//                         ? "bg-green-100 text-green-700"
//                         : cabin.status === "OCCUPIED"
//                         ? "bg-red-100 text-red-700"
//                         : "bg-yellow-100 text-yellow-700"
//                     }
//                   `}
//                   >

//                     {cabin.status}

//                   </span>

//                 </td>

//                 <td>

//                   <span
//                     className={`px-3 py-1 rounded-full text-xs font-semibold

//                     ${
//                       cabin.active
//                         ? "bg-green-100 text-green-700"
//                         : "bg-red-100 text-red-700"
//                     }
//                   `}
//                   >

//                     {cabin.active ? "YES" : "NO"}

//                   </span>

//                 </td>

//                 <td>

//                   {cabin.location}

//                 </td>

//                 <td>

//                   <button
//                     onClick={() =>
//                       handleEdit(cabin)
//                     }
//                     className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-lg flex items-center gap-2"
//                   >

//                     <Edit size={16} />

//                     Edit

//                   </button>

//                 </td>

//               </tr>

//             ))

//           )}

//           </tbody>

//         </table>

//       </div>

//       {open && (

//         <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">

//           <div className="bg-white rounded-2xl shadow-xl w-full max-w-xl p-6">

//             <div className="flex justify-between items-center mb-6">

//               <h2 className="text-2xl font-bold">

//                 Update Cabin

//               </h2>

//               <button
//                 onClick={() =>
//                   setOpen(false)
//                 }
//               >

//                 <X />

//               </button>

//             </div>

//             <div className="grid grid-cols-2 gap-5">
//                               <div>

//                 <label className="block text-sm font-medium mb-2">
//                   Cabin Name
//                 </label>

//                 <input
//                   type="text"
//                   value={form.cabinName}
//                   onChange={(e) =>
//                     setForm({
//                       ...form,
//                       cabinName: e.target.value,
//                     })
//                   }
//                   className="w-full border border-slate-300 rounded-xl px-4 py-3"
//                 />

//               </div>

//               <div>

//                 <label className="block text-sm font-medium mb-2">
//                   Floor
//                 </label>

//                 <input
//                   type="number"
//                   value={form.floor}
//                   onChange={(e) =>
//                     setForm({
//                       ...form,
//                       floor: Number(e.target.value),
//                     })
//                   }
//                   className="w-full border border-slate-300 rounded-xl px-4 py-3"
//                 />

//               </div>

//               <div>

//                 <label className="block text-sm font-medium mb-2">
//                   Capacity
//                 </label>

//                 <input
//                   type="number"
//                   value={form.capacity}
//                   onChange={(e) =>
//                     setForm({
//                       ...form,
//                       capacity: Number(e.target.value),
//                     })
//                   }
//                   className="w-full border border-slate-300 rounded-xl px-4 py-3"
//                 />

//               </div>

//               <div>

//                 <label className="block text-sm font-medium mb-2">
//                   Location
//                 </label>

//                 <input
//                   type="text"
//                   value={form.location}
//                   onChange={(e) =>
//                     setForm({
//                       ...form,
//                       location: e.target.value,
//                     })
//                   }
//                   className="w-full border border-slate-300 rounded-xl px-4 py-3"
//                 />

//               </div>

//               <div className="col-span-2">

//                 <label className="block text-sm font-medium mb-2">
//                   Amenities (Comma Separated)
//                 </label>

//                 <input
//                   type="text"
//                   value={form.amenities.join(", ")}
//                   onChange={(e) =>
//                     setForm({
//                       ...form,
//                       amenities: e.target.value
//                         .split(",")
//                         .map((item) => item.trim())
//                         .filter((item) => item.length > 0),
//                     })
//                   }
//                   className="w-full border border-slate-300 rounded-xl px-4 py-3"
//                 />

//               </div>

//               <div>

//                 <label className="block text-sm font-medium mb-2">
//                   Status
//                 </label>

//                 <select
//                   value={form.status}
//                   onChange={(e) =>
//                     setForm({
//                       ...form,
//                       status: e.target.value as any,
//                     })
//                   }
//                   className="w-full border border-slate-300 rounded-xl px-4 py-3"
//                 >

//                   <option value="AVAILABLE">
//                     AVAILABLE
//                   </option>

//                   <option value="OCCUPIED">
//                     OCCUPIED
//                   </option>

//                   <option value="MAINTENANCE">
//                     MAINTENANCE
//                   </option>

//                 </select>

//               </div>

//               <div>

//                 <label className="block text-sm font-medium mb-2">
//                   Active
//                 </label>

//                 <select
//                   value={form.active ? "true" : "false"}
//                   onChange={(e) =>
//                     setForm({
//                       ...form,
//                       active: e.target.value === "true",
//                     })
//                   }
//                   className="w-full border border-slate-300 rounded-xl px-4 py-3"
//                 >

//                   <option value="true">
//                     Active
//                   </option>

//                   <option value="false">
//                     Inactive
//                   </option>

//                 </select>

//               </div>

//             </div>

//             <div className="flex justify-end gap-3 mt-8">
//                               <button
//                 onClick={() => setOpen(false)}
//                 className="px-6 py-3 rounded-xl border border-slate-300 hover:bg-slate-100 transition"
//               >
//                 Cancel
//               </button>

//               <button
//                 onClick={handleUpdate}
//                 className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-2 transition"
//               >
//                 <Save size={18} />
//                 Update Cabin
//               </button>

//             </div>

//           </div>

//         </div>

//       )}

//       <div className="border-t border-slate-200 px-6 py-4 flex justify-between items-center">

//         <p className="text-sm text-slate-500">

//           Total Cabins :
//           <span className="font-semibold ml-2">

//             {cabins.length}

//           </span>

//         </p>

//         <button
//           onClick={loadCabins}
//           className="bg-slate-800 hover:bg-slate-900 text-white px-5 py-2 rounded-lg transition"
//         >
//           Reload
//         </button>

//       </div>

//     </div>

//   );

// }
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import {
  Edit,
  RefreshCcw,
  Save,
  X,
  MapPin,
  Users,
  Layers,
  Settings2,
  CheckCircle2,
  AlertCircle
} from "lucide-react";

import { getCabins, updateCabin } from "../../services/api";
import { Cabin, UpdateCabinRequest } from "../../types";

export default function CabinManagement() {
  const [loading, setLoading] = useState(true);
  const [cabins, setCabins] = useState<Cabin[]>([]);
  const [selectedCabin, setSelectedCabin] = useState<Cabin | null>(null);
  const [open, setOpen] = useState(false);

  const [form, setForm] = useState<UpdateCabinRequest>({
    cabinName: "",
    floor: 1,
    capacity: 1,
    location: "",
    amenities: [],
    status: "AVAILABLE",
    active: true,
  });

  const loadCabins = async () => {
    try {
      setLoading(true);
      const response = await getCabins();
      setCabins(response.data.data);
    } catch (err: any) {
      toast.error(err?.response?.data?.message ?? "Unable to load cabins.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCabins();
  }, []);

  const handleEdit = (cabin: Cabin) => {
    setSelectedCabin(cabin);
    setForm({
      cabinName: cabin.cabinName,
      floor: cabin.floor,
      capacity: cabin.capacity,
      location: cabin.location,
      amenities: cabin.amenities,
      status: cabin.status,
      active: cabin.active,
    });
    setOpen(true);
  };

  const handleUpdate = async () => {
    if (!selectedCabin) return;
    try {
      await updateCabin(selectedCabin.id, form);
      toast.success("Cabin Updated Successfully");
      setOpen(false);
      loadCabins();
    } catch (err: any) {
      toast.error(err?.response?.data?.message ?? "Update failed.");
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
        <div className="h-10 w-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 font-bold tracking-widest uppercase text-[10px]">Syncing Assets...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Top Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <p className="text-emerald-500 font-bold text-xs uppercase tracking-widest mb-2">Resource Management</p>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Cabin Inventory</h1>
        </div>
        <button
          onClick={loadCabins}
          className="flex items-center gap-2 px-6 py-3.5 bg-white border border-slate-200 rounded-2xl text-slate-600 font-bold text-sm hover:bg-slate-50 transition-all active:scale-95 shadow-sm"
        >
          <RefreshCcw size={18} />
          Refresh List
        </button>
      </div>

      {/* Main Table Container */}
      <div className="overflow-x-auto pb-4">
        <table className="modern-table">
          <thead>
            <tr>
              <th>Cabin Details</th>
              <th>Specifications</th>
              <th>Status</th>
              <th>Visibility</th>
              <th className="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {cabins.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-20 text-slate-400 font-bold italic bg-white rounded-3xl">
                  No cabin records found in database.
                </td>
              </tr>
            ) : (
              cabins.map((cabin) => (
                <tr key={cabin.id} className="group">
                  <td className="min-w-[200px]">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-xl bg-slate-50 text-slate-400 flex items-center justify-center group-hover:bg-emerald-50 group-hover:text-emerald-500 transition-colors">
                        <Layers size={20} />
                      </div>
                      <div>
                        <div className="font-black text-slate-900">{cabin.cabinName}</div>
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-bold uppercase mt-0.5">
                          <MapPin size={10} /> {cabin.location}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                        <Users size={12} className="text-slate-400" /> {cabin.capacity} Seats
                      </div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Floor {cabin.floor}</div>
                    </div>
                  </td>
                  <td>
                    <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tight border ${
                      cabin.status === "AVAILABLE"
                        ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                        : cabin.status === "OCCUPIED"
                        ? "bg-rose-50 text-rose-700 border-rose-100"
                        : "bg-amber-50 text-amber-700 border-amber-100"
                    }`}>
                      {cabin.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      {cabin.active ? (
                        <CheckCircle2 size={16} className="text-emerald-500" />
                      ) : (
                        <AlertCircle size={16} className="text-slate-300" />
                      )}
                      <span className={`text-[10px] font-bold uppercase ${cabin.active ? "text-slate-700" : "text-slate-400"}`}>
                        {cabin.active ? "Public" : "Hidden"}
                      </span>
                    </div>
                  </td>
                  <td className="text-right">
                    <button
                      onClick={() => handleEdit(cabin)}
                      className="inline-flex items-center gap-2 bg-slate-900 text-white px-4 py-2.5 rounded-xl font-bold text-xs hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/10 active:scale-95"
                    >
                      <Edit size={14} />
                      Edit
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Edit Modal */}
      {open && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-[32px] shadow-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-slate-900 rounded-2xl flex items-center justify-center text-emerald-400">
                  <Settings2 size={20} />
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight">Modify Resource</h2>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">ID: CMS-00{selectedCabin?.id}</p>
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="p-2 hover:bg-white rounded-xl transition-colors text-slate-400 hover:text-slate-900">
                <X size={24} />
              </button>
            </div>

            <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Cabin Name</label>
                <input
                  type="text"
                  value={form.cabinName}
                  onChange={(e) => setForm({ ...form, cabinName: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl px-5 py-3.5 transition-all outline-none font-bold text-slate-700"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Location / Zone</label>
                <input
                  type="text"
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl px-5 py-3.5 transition-all outline-none font-bold text-slate-700"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Floor Number</label>
                <input
                  type="number"
                  value={form.floor}
                  onChange={(e) => setForm({ ...form, floor: Number(e.target.value) })}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl px-5 py-3.5 transition-all outline-none font-bold text-slate-700"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Total Capacity</label>
                <input
                  type="number"
                  value={form.capacity}
                  onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl px-5 py-3.5 transition-all outline-none font-bold text-slate-700"
                />
              </div>

              <div className="md:col-span-2 space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Amenities (Comma separated)</label>
                <input
                  type="text"
                  value={form.amenities.join(", ")}
                  onChange={(e) => setForm({
                      ...form,
                      amenities: e.target.value.split(",").map(i => i.trim()).filter(i => i.length > 0),
                    })
                  }
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl px-5 py-3.5 transition-all outline-none font-bold text-slate-700"
                  placeholder="e.g. WiFi, Projector, Whiteboard"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Current Status</label>
                <select
                  value={form.status}
                  onChange={(e) => setForm({ ...form, status: e.target.value as any })}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl px-5 py-3.5 transition-all outline-none font-bold text-slate-700"
                >
                  <option value="AVAILABLE">AVAILABLE</option>
                  <option value="OCCUPIED">OCCUPIED</option>
                  <option value="MAINTENANCE">MAINTENANCE</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">System Active</label>
                <select
                  value={form.active ? "true" : "false"}
                  onChange={(e) => setForm({ ...form, active: e.target.value === "true" })}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 focus:bg-white rounded-2xl px-5 py-3.5 transition-all outline-none font-bold text-slate-700"
                >
                  <option value="true">Active (Visible to users)</option>
                  <option value="false">Inactive (Hidden)</option>
                </select>
              </div>
            </div>

            <div className="p-8 bg-slate-50/50 flex justify-end gap-3">
              <button
                onClick={() => setOpen(false)}
                className="px-6 py-3.5 rounded-2xl font-bold text-xs uppercase tracking-widest text-slate-500 hover:bg-white transition-all"
              >
                Discard
              </button>
              <button
                onClick={handleUpdate}
                className="px-8 py-3.5 bg-emerald-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-500/20 hover:bg-emerald-600 transition-all flex items-center gap-2"
              >
                <Save size={16} />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
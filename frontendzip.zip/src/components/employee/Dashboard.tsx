import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import {
  Building2,
  CalendarDays,
  CheckCircle2,
  Clock3,
  RefreshCcw,
} from "lucide-react";

import {
  getDashboardStats,
  getCabins,
  getMyBookings,
} from "../../services/api";

import {
  DashboardStats,
  Cabin,
  Booking,
} from "../../types";

export default function Dashboard() {

  const [loading, setLoading] = useState(true);

  const [stats, setStats] = useState<DashboardStats>({
  totalCabins: 0,
  availableCabins: 0,
  inactiveCabins: 0,
  pendingBookings: 0,
  approvedBookings: 0,
  rejectedBookings: 0,
});

  const [cabins, setCabins] =
    useState<Cabin[]>([]);

  const [bookings, setBookings] =
    useState<Booking[]>([]);

  const loadDashboard = async () => {

    try {

      setLoading(true);

      const [
        dashboardRes,
        cabinRes,
        bookingRes,
      ] = await Promise.all([
        getDashboardStats(),
        getCabins(),
        getMyBookings(),
      ]);

      setStats(dashboardRes.data.data);

      setCabins(cabinRes.data.data);

      setBookings(bookingRes.data.data);

    } catch (err: any) {

      toast.error(
        err?.response?.data?.message ??
        "Unable to load dashboard."
      );

    } finally {

      setLoading(false);

    }

  };

  useEffect(() => {

    loadDashboard();

  }, []);

  if (loading) {

    return (

      <div className="flex justify-center items-center h-[70vh]">

        <div className="text-xl font-semibold text-slate-600">

          Loading Dashboard...

        </div>

      </div>

    );

  }

  return (

    <div className="space-y-8">

      <div className="flex justify-between items-center">

        <div>

          <h1 className="text-3xl font-bold text-slate-800">

            Employee Dashboard

          </h1>

          <p className="text-slate-500 mt-1">

            Welcome back.

          </p>

        </div>

        <button
          onClick={loadDashboard}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-xl flex items-center gap-2"
        >

          <RefreshCcw size={18} />

          Refresh

        </button>

      </div>

      {/* Stats */}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">

        <div className="bg-white rounded-2xl shadow border border-slate-200 p-5">

          <div className="flex justify-between">

            <div>

              <p className="text-slate-500 text-sm">

                Available Cabins

              </p>

              <h2 className="text-3xl font-bold mt-2">

                {stats.availableCabins}

              </h2>

            </div>

            <Building2
              className="text-green-600"
              size={34}
            />

          </div>

        </div>

        <div className="bg-white rounded-2xl shadow border border-slate-200 p-5">

          <div className="flex justify-between">

            <div>

              <p className="text-slate-500 text-sm">

                My Bookings

              </p>

              <h2 className="text-3xl font-bold mt-2">

                {bookings.length}

              </h2>

            </div>

            <CalendarDays
              className="text-indigo-600"
              size={34}
            />

          </div>

        </div>

        <div className="bg-white rounded-2xl shadow border border-slate-200 p-5">

          <div className="flex justify-between">

            <div>

              <p className="text-slate-500 text-sm">

                Pending

              </p>

              <h2 className="text-3xl font-bold mt-2 text-yellow-600">

                {
                  bookings.filter(
                    b => b.status === "PENDING"
                  ).length
                }

              </h2>

            </div>

            <Clock3
              className="text-yellow-600"
              size={34}
            />

          </div>

        </div>

        <div className="bg-white rounded-2xl shadow border border-slate-200 p-5">

          <div className="flex justify-between">

            <div>

              <p className="text-slate-500 text-sm">

                Approved

              </p>

              <h2 className="text-3xl font-bold mt-2 text-green-600">

                {
                  bookings.filter(
                    b => b.status === "APPROVED"
                  ).length
                }

              </h2>

            </div>

            <CheckCircle2
              className="text-green-600"
              size={34}
            />

          </div>

        </div>

      </div>
            {/* Available Cabins */}

      <div className="bg-white rounded-2xl border border-slate-200 shadow">

        <div className="p-6 border-b">

          <h2 className="text-xl font-bold">

            Available Cabins

          </h2>

          <p className="text-slate-500 mt-1">

            Cabins currently available for booking.

          </p>

        </div>

        <div className="overflow-x-auto">

          <table>

            <thead>

              <tr>

                <th>Cabin</th>

                <th>Floor</th>

                <th>Capacity</th>

                <th>Status</th>

                <th>Location</th>

              </tr>

            </thead>

            <tbody>

              {cabins.length === 0 ? (

                <tr>

                  <td
                    colSpan={5}
                    className="text-center py-12 text-slate-500"
                  >

                    No Cabins Available

                  </td>

                </tr>

              ) : (

                cabins.map((cabin) => (

                  <tr key={cabin.id}>

                    <td className="font-semibold">

                      {cabin.cabinName}

                    </td>

                    <td>

                      {cabin.floor}

                    </td>

                    <td>

                      {cabin.capacity}

                    </td>

                    <td>

                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold

                        ${
                          cabin.status === "AVAILABLE"
                            ? "bg-green-100 text-green-700"
                            : cabin.status === "OCCUPIED"
                            ? "bg-red-100 text-red-700"
                            : "bg-yellow-100 text-yellow-700"
                        }
                      `}
                      >

                        {cabin.status}

                      </span>

                    </td>

                    <td>

                      {cabin.location}

                    </td>

                  </tr>

                ))

              )}

            </tbody>

          </table>

        </div>

      </div>

      {/* My Recent Bookings */}

      <div className="bg-white rounded-2xl border border-slate-200 shadow">

        <div className="p-6 border-b">

          <h2 className="text-xl font-bold">

            My Recent Bookings

          </h2>

        </div>

        <div className="overflow-x-auto">

          <table>

            <thead>

              <tr>

                <th>Cabin</th>

                <th>Date</th>

                <th>Time</th>

                <th>Purpose</th>

                <th>Status</th>

              </tr>

            </thead>

            <tbody>
                              {bookings.length === 0 ? (

                <tr>

                  <td
                    colSpan={5}
                    className="text-center py-12 text-slate-500"
                  >

                    No Bookings Found

                  </td>

                </tr>

              ) : (

                bookings.map((booking) => (

                  <tr key={booking.id}>

                    <td className="font-semibold">

                      {booking.cabinName}

                    </td>

                    <td>

                      {booking.bookingDate}

                    </td>

                    <td>

                      {booking.startTime}
                      {" - "}
                      {booking.endTime}

                    </td>

                    <td>

                      {booking.purpose}

                    </td>

                    <td>

                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold

                        ${
                          booking.status === "APPROVED"
                            ? "bg-green-100 text-green-700"
                            : booking.status === "PENDING"
                            ? "bg-yellow-100 text-yellow-700"
                            : booking.status === "REJECTED"
                            ? "bg-red-100 text-red-700"
                            : "bg-slate-200 text-slate-700"
                        }
                      `}
                      >

                        {booking.status}

                      </span>

                    </td>

                  </tr>

                ))

              )}

            </tbody>

          </table>

        </div>

      </div>

      {/* Quick Summary */}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">

        <div className="bg-indigo-600 rounded-2xl text-white p-6">

          <h3 className="text-lg font-semibold">

            Available Cabins

          </h3>

          <p className="text-5xl font-bold mt-4">

            {stats.availableCabins}

          </p>

          <p className="mt-3 text-indigo-100">

            Ready for booking

          </p>

        </div>

        <div className="bg-green-600 rounded-2xl text-white p-6">

          <h3 className="text-lg font-semibold">

            Approved Bookings

          </h3>

          <p className="text-5xl font-bold mt-4">

            {
              bookings.filter(
                (b) => b.status === "APPROVED"
              ).length
            }

          </p>

          <p className="mt-3 text-green-100">

            Successfully approved

          </p>

        </div>

        <div className="bg-yellow-500 rounded-2xl text-white p-6">

          <h3 className="text-lg font-semibold">

            Pending Requests

          </h3>

          <p className="text-5xl font-bold mt-4">

            {
              bookings.filter(
                (b) => b.status === "PENDING"
              ).length
            }

          </p>

          <p className="mt-3 text-yellow-100">

            Waiting for admin approval

          </p>

        </div>

      </div>
            <div className="border-t border-slate-200 px-6 py-4 flex justify-between items-center">

        <p className="text-sm text-slate-500">

          Total Bookings :
          <span className="font-semibold ml-2">

            {bookings.length}

          </span>

        </p>

        <button
          onClick={loadDashboard}
          className="bg-slate-800 hover:bg-slate-900 text-white px-5 py-2 rounded-lg transition"
        >

          Reload

        </button>

      </div>

    </div>

  );

}
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import {
  RefreshCcw,
  Trash2,
} from "lucide-react";

import {
  getMyBookings,
  cancelBooking,
} from "../../services/api";

import { Booking } from "../../types";

export default function MyBookings() {

  const [loading, setLoading] =
    useState(true);

  const [bookings, setBookings] =
    useState<Booking[]>([]);

  const loadBookings = async () => {

    try {

      setLoading(true);

      const response =
        await getMyBookings();

      setBookings(response.data.data);

    } catch (err: any) {

      toast.error(
        err?.response?.data?.message ??
        "Unable to load bookings."
      );

    } finally {

      setLoading(false);

    }

  };

  useEffect(() => {

    loadBookings();

  }, []);

  const handleCancel = async (
    bookingId: number
  ) => {

    if (
      !window.confirm(
        "Cancel this booking?"
      )
    ) {
      return;
    }

    try {

      await cancelBooking(
        bookingId
      );

      toast.success(
        "Booking Cancelled"
      );

      loadBookings();

    } catch (err: any) {

      toast.error(
        err?.response?.data?.message ??
        "Unable to cancel booking."
      );

    }

  };

  const getBadge = (
    status: string
  ) => {

    switch (status) {

      case "APPROVED":
        return "bg-green-100 text-green-700";

      case "PENDING":
        return "bg-yellow-100 text-yellow-700";

      case "REJECTED":
        return "bg-red-100 text-red-700";

      case "CANCELLED":
        return "bg-slate-200 text-slate-700";

      default:
        return "bg-slate-100 text-slate-700";

    }

  };

  if (loading) {

    return (

      <div className="flex justify-center items-center h-[60vh]">

        <div className="text-lg font-semibold text-slate-500">

          Loading Bookings...

        </div>

      </div>

    );

  }

  return (

    <div className="bg-white rounded-2xl shadow border border-slate-200">

      <div className="p-6 border-b flex justify-between items-center">

        <div>

          <h1 className="text-2xl font-bold">

            My Bookings

          </h1>

          <p className="text-slate-500 mt-1">

            View and manage your bookings.

          </p>

        </div>

        <button
          onClick={loadBookings}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-xl flex items-center gap-2"
        >

          <RefreshCcw size={18} />

          Refresh

        </button>

      </div>

      <div className="overflow-x-auto">

        <table>

          <thead>

            <tr>

              <th>Cabin</th>

              <th>Date</th>

              <th>Time</th>

              <th>Purpose</th>

              <th>Status</th>

              <th>Action</th>

            </tr>

          </thead>

          <tbody>
                      {bookings.length === 0 ? (

            <tr>

              <td
                colSpan={6}
                className="text-center py-12 text-slate-500"
              >

                You don't have any bookings.

              </td>

            </tr>

          ) : (

            bookings.map((booking) => (

              <tr key={booking.id}>

                <td className="font-semibold">

                  {booking.cabinName}

                </td>

                <td>

                  {booking.bookingDate}

                </td>

                <td>

                  {booking.startTime}
                  {" - "}
                  {booking.endTime}

                </td>

                <td>

                  {booking.purpose}

                </td>

                <td>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${getBadge(
                      booking.status
                    )}`}
                  >

                    {booking.status}

                  </span>

                </td>

                <td>

                  {booking.status === "PENDING" ? (

                    <button
                      onClick={() =>
                        handleCancel(booking.id)
                      }
                      className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
                    >

                      <Trash2 size={16} />

                      Cancel

                    </button>

                  ) : (

                    <span className="text-slate-400 text-sm">

                      —

                    </span>

                  )}

                </td>

              </tr>

            ))

          )}

          </tbody>

        </table>

      </div>
            <div className="border-t border-slate-200 px-6 py-4 flex justify-between items-center">

        <div className="text-sm text-slate-500">

          Total Bookings :
          <span className="font-semibold ml-2">

            {bookings.length}

          </span>

        </div>

        <button
          onClick={loadBookings}
          className="bg-slate-800 hover:bg-slate-900 text-white px-5 py-2 rounded-lg transition"
        >

          Reload

        </button>

      </div>

    </div>

  );

}
import { useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";
import { Search, CalendarPlus, RefreshCcw } from "lucide-react";

import { getCabins } from "../../services/api";
import { Cabin } from "../../types";

import BookingModal from "./BookingModal";

export default function CabinList() {

  const [loading, setLoading] = useState(true);

  const [cabins, setCabins] =
    useState<Cabin[]>([]);

  const [search, setSearch] =
    useState("");

  const [selectedCabin, setSelectedCabin] =
    useState<Cabin | null>(null);

  const [openModal, setOpenModal] =
    useState(false);

  const loadCabins = async () => {

    try {

      setLoading(true);

      const response =
        await getCabins();

      setCabins(response.data.data);

    } catch (err: any) {

      toast.error(
        err?.response?.data?.message ??
        "Unable to load cabins."
      );

    } finally {

      setLoading(false);

    }

  };

  useEffect(() => {

    loadCabins();

  }, []);

  const filteredCabins = useMemo(() => {

    if (!search.trim())
      return cabins;

    const value =
      search.toLowerCase();

    return cabins.filter((cabin) =>
      cabin.cabinName
        .toLowerCase()
        .includes(value) ||
      cabin.location
        .toLowerCase()
        .includes(value)
    );

  }, [cabins, search]);

  if (loading) {

    return (

      <div className="flex justify-center items-center h-[60vh]">

        <div className="text-xl font-semibold text-slate-500">

          Loading Cabins...

        </div>

      </div>

    );

  }

  return (

    <div className="space-y-6">

      <div className="flex justify-between items-center">

        <div>

          <h1 className="text-3xl font-bold">

            Available Cabins

          </h1>

          <p className="text-slate-500 mt-1">

            Book a cabin for your meeting.

          </p>

        </div>

        <button
          onClick={loadCabins}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-xl flex items-center gap-2"
        >

          <RefreshCcw size={18} />

          Refresh

        </button>

      </div>

      <div className="relative max-w-md">

        <Search
          className="absolute left-4 top-4 text-slate-400"
          size={18}
        />

        <input
          type="text"
          placeholder="Search cabin..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
          className="w-full border border-slate-300 rounded-xl pl-11 pr-4 py-3"
        />

      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredCabins.length === 0 ? (

          <div className="col-span-full bg-white rounded-2xl shadow border border-slate-200 py-16 text-center">

            <h2 className="text-2xl font-semibold text-slate-700">

              No Cabins Found

            </h2>

            <p className="text-slate-500 mt-2">

              Try searching with another keyword.

            </p>

          </div>

        ) : (

          filteredCabins.map((cabin) => (

            <div
              key={cabin.id}
              className="bg-white rounded-2xl border border-slate-200 shadow hover:shadow-lg transition"
            >

              <div className="p-6">

                <div className="flex justify-between items-start">

                  <div>

                    <h2 className="text-2xl font-bold">

                      {cabin.cabinName}

                    </h2>

                    <p className="text-slate-500 mt-1">

                      {cabin.location}

                    </p>

                  </div>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold

                    ${
                      cabin.status === "AVAILABLE"
                        ? "bg-green-100 text-green-700"
                        : cabin.status === "OCCUPIED"
                        ? "bg-red-100 text-red-700"
                        : "bg-yellow-100 text-yellow-700"
                    }
                  `}
                  >

                    {cabin.status}

                  </span>

                </div>

                <div className="mt-6 space-y-2">

                  <div className="flex justify-between">

                    <span className="text-slate-500">

                      Floor

                    </span>

                    <span className="font-semibold">

                      {cabin.floor}

                    </span>

                  </div>

                  <div className="flex justify-between">

                    <span className="text-slate-500">

                      Capacity

                    </span>

                    <span className="font-semibold">

                      {cabin.capacity}

                    </span>

                  </div>

                  <div>

                    <p className="text-slate-500 mb-2">

                      Amenities

                    </p>

                    <div className="flex flex-wrap gap-2">

                      {cabin.amenities.map((amenity) => (

                        <span
                          key={amenity}
                          className="bg-slate-100 px-3 py-1 rounded-full text-xs"
                        >

                          {amenity}

                        </span>

                      ))}

                    </div>

                  </div>

                </div>

                <button
                  disabled={
                    !cabin.active ||
                    cabin.status !== "AVAILABLE"
                  }
                  onClick={() => {

                    setSelectedCabin(cabin);

                    setOpenModal(true);

                  }}
                  className={`w-full mt-6 py-3 rounded-xl flex items-center justify-center gap-2 font-semibold transition

                  ${
                    cabin.active &&
                    cabin.status === "AVAILABLE"
                      ? "bg-indigo-600 hover:bg-indigo-700 text-white"
                      : "bg-slate-300 text-slate-500 cursor-not-allowed"
                  }
                `}
                >

                  <CalendarPlus size={18} />

                  Book Cabin

                </button>

              </div>

            </div>

          ))

        )}

      </div>

      {selectedCabin && (        <BookingModal
          open={openModal}
          cabin={selectedCabin}
          onClose={() => {
            setOpenModal(false);
            setSelectedCabin(null);
          }}
          onSuccess={() => {
            setOpenModal(false);
            setSelectedCabin(null);

            toast.success(
              "Booking Request Submitted Successfully"
            );
          }}
        />
      )}

    </div>

  );

}
import { Routes, Route, Navigate } from "react-router-dom";

import Login from "../pages/Login";
import ChangePassword from "../pages/ChangePassword";

import AdminLayout from "../layouts/AdminLayout";
import EmployeeLayout from "../layouts/EmployeeLayout";

import ProtectedRoute from "./ProtectedRoute";
import RoleProtectedRoute from "./RoleProtectedRoute";

export default function AppRoutes() {
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  return (
    <Routes>
      {/* Default Route */}
      <Route
        path="/"
        element={
          token ? (
            <Navigate
              to={user.role === "ADMIN" ? "/admin" : "/employee"}
              replace
            />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />

      {/* Public Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/change-password" element={<ChangePassword />} />

      {/* Protected Routes */}
      <Route element={<ProtectedRoute />}>
        {/* Admin */}
        <Route element={<RoleProtectedRoute allowedRole="ADMIN" />}>
          <Route path="/admin/*" element={<AdminLayout />} />
        </Route>

        {/* Employee */}
        <Route element={<RoleProtectedRoute allowedRole="EMPLOYEE" />}>
          <Route path="/employee/*" element={<EmployeeLayout />} />
        </Route>
      </Route>

      {/* Unknown Routes */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
import { useEffect, useState } from "react";
import Login from "./pages/Login";
import AdminLayout from "./layouts/AdminLayout";
import EmployeeLayout from "./layouts/EmployeeLayout";
import ChangePassword from "./pages/ChangePassword";

export default function App() {
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState<string | null>(null);
  const [role, setRole] = useState<string | null>(null);
  const [changePasswordMode, setChangePasswordMode] = useState(false);

  useEffect(() => {
    const savedToken = localStorage.getItem("token");
    const savedUser = localStorage.getItem("user");



    const changePasswordEmail =
    sessionStorage.getItem("changePasswordEmail");

    if (changePasswordEmail) {
     setChangePasswordMode(true);
    }

    if (savedToken) {
      setToken(savedToken);
    }

    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        setRole(user.role);
      } catch (e) {
        localStorage.clear();
      }
    }

    setLoading(false);
  }, []);

  const handleLogin = (jwt: string, userRole: string) => {
    setToken(jwt);
    setRole(userRole);
  };

  const handleLogout = () => {
    localStorage.clear();
    setToken(null);
    setRole(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="bg-white px-8 py-6 rounded-2xl shadow-lg border border-slate-200">
          <h2 className="text-xl font-semibold text-slate-700">
            Loading...
          </h2>
        </div>
      </div>
    );
  }

  if (changePasswordMode) {
    return (
        <ChangePassword
            onSuccess={() => {
                sessionStorage.removeItem("changePasswordEmail");
                setChangePasswordMode(false);
            }}
        />
    );
}

if (!token) {
    return <Login onLogin={handleLogin} />;
}

  if (role === "ADMIN") {
    return <AdminLayout onLogout={handleLogout} />;
  }

  return <EmployeeLayout onLogout={handleLogout} />;
}
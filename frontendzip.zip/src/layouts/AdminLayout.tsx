import { useState } from "react";
import { 
  LayoutDashboard,
  Building2,
  CalendarDays,
  ClipboardList,
  Users,
  LogOut,
  Menu,
  ChevronRight,
  ShieldCheck
} from "lucide-react";

import Dashboard from "../components/admin/Dashboard";
import CabinManagement from "../components/admin/CabinManagement";
import PendingBookings from "../components/admin/PendingBookings";
import BookingHistory from "../components/admin/BookingHistory";
import UserManagement from "../components/admin/UserManagement";

interface Props {
  onLogout: () => void;
}

type Tab =  "dashboard" | "cabins" | "pending" | "users" | "history";

export default function AdminLayout({ onLogout }: Props) {

  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const initials =
    user?.name
      ?.split(" ")
      .map((word: string) => word[0])
      .join("")
      .substring(0, 2)
      .toUpperCase() || "AU";

  const titles = {
    dashboard: "Dashboard",

  cabins: "Cabin Management",

  pending: "Booking Requests",

  users: "User Management",

  history: "Booking History",
  };

  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const menuItems = [

    {
        id: "dashboard",
        label: "Overview",
        icon: LayoutDashboard
    },

    {
        id: "cabins",
        label: "Cabins",
        icon: Building2
    },

    {
        id: "pending",
        label: "Requests",
        icon: CalendarDays
    },

    {
        id: "users",
        label: "Users",
        icon: Users
    },

    {
        id: "history",
        label: "Logs",
        icon: ClipboardList
    }

];

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard": return <Dashboard />;
      case "cabins": return <CabinManagement />;
      case "pending": return <PendingBookings />;
      case "users": return <UserManagement />;
      case "history": return <BookingHistory />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f1f5f9] flex overflow-hidden">
      {sidebarOpen && (
  <div
    onClick={() => setSidebarOpen(false)}
    className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 lg:hidden"
  />
)}
      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50 
        w-72 glass transition-all duration-500 transform
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
      `}>
        <div className="flex flex-col h-full p-6">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-12 px-2">
            <div className="h-11 w-11 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <ShieldCheck className="text-white h-6 w-6" />
            </div>
            <span className="text-2xl font-black tracking-tighter text-slate-900">OCaBiN</span>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as Tab);
                  setSidebarOpen(false);
                }}
                className={`
                  w-full flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all duration-200 group
                  ${activeTab === item.id 
                    ? "bg-slate-900 text-white shadow-xl shadow-slate-900/20" 
                    : "text-slate-500 hover:bg-white hover:text-slate-900 hover:shadow-sm"}
                `}
              >
                <div className="flex items-center gap-3">
                  <item.icon size={20} className={activeTab === item.id ? "text-emerald-400" : "group-hover:text-emerald-500"} />
                  <span className="font-bold text-sm">{item.label}</span>
                </div>
                {activeTab === item.id && <ChevronRight size={14} className="text-slate-500" />}
              </button>
            ))}
          </nav>

          {/* Footer / Logout */}
          <div className="pt-6 border-t border-slate-100">
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-rose-500 font-bold text-sm hover:bg-rose-50 transition-colors"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
          <header className="sticky top-0 z-30 h-20 flex items-center justify-between px-8 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
          <button className="lg:hidden p-2 text-slate-600" onClick={() => setSidebarOpen(true)}>
            <Menu size={24} />
          </button>

          <div className="hidden md:block">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.25em]">
               OCaBiN Admin
              </p>

              <h1 className="text-2xl font-black text-slate-900">
                {titles[activeTab]}
              </h1>
          </div>

          <div className="flex items-center gap-4">

  <div className="text-right hidden sm:block">

    <p className="text-sm font-black text-slate-900 leading-none">
      {user.name}
    </p>

    <p className="text-[10px] font-bold text-emerald-500 uppercase mt-1">
      {user.role}
    </p>

  </div>

  <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg flex items-center justify-center font-black">

    {initials}

  </div>

</div>
        </header>

        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-7xl mx-auto animate-fade-in">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
}
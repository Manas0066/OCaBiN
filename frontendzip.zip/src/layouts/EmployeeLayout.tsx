import { useState } from "react";
import {
  Home,
  Building2,
  CalendarCheck,
  LogOut,
  Menu,
  X,
} from "lucide-react";

import Dashboard from "../components/employee/Dashboard";
import CabinList from "../components/employee/CabinList";
import MyBookings from "../components/employee/MyBookings";

interface Props {
  onLogout: () => void;
}

type Tab =
  | "dashboard"
  | "cabins"
  | "bookings";

export default function EmployeeLayout({
  onLogout,
}: Props) {

  const [activeTab, setActiveTab] =
    useState<Tab>("dashboard");

  const [sidebarOpen, setSidebarOpen] =
    useState(false);

  const renderContent = () => {

    switch (activeTab) {

      case "dashboard":
        return <Dashboard />;

      case "cabins":
        return <CabinList />;

      case "bookings":
        return <MyBookings />;

      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex">

      {/* Sidebar */}

      <aside
        className={`
        fixed lg:static
        z-40
        h-screen
        w-72
        bg-indigo-700
        text-white
        transition-all

        ${
          sidebarOpen
            ? "left-0"
            : "-left-72 lg:left-0"
        }
      `}
      >

        <div className="flex items-center justify-between p-6 border-b border-indigo-600">

          <div>

            <h2 className="text-2xl font-bold">

              Cabin CMS

            </h2>

            <p className="text-indigo-200 text-sm mt-1">

              Employee Portal

            </p>

          </div>

          <button
            className="lg:hidden"
            onClick={() =>
              setSidebarOpen(false)
            }
          >
            <X />
          </button>

        </div>

        <nav className="mt-6 px-3 space-y-2">

          <button
            onClick={() =>
              setActiveTab("dashboard")
            }
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition

            ${
              activeTab === "dashboard"
                ? "bg-white text-indigo-700"
                : "hover:bg-indigo-600"
            }
          `}
          >

            <Home size={20} />

            Dashboard

          </button>

          <button
            onClick={() =>
              setActiveTab("cabins")
            }
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition

            ${
              activeTab === "cabins"
                ? "bg-white text-indigo-700"
                : "hover:bg-indigo-600"
            }
          `}
          >

            <Building2 size={20} />

            Available Cabins

          </button>

          <button
            onClick={() =>
              setActiveTab("bookings")
            }
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition

            ${
              activeTab === "bookings"
                ? "bg-white text-indigo-700"
                : "hover:bg-indigo-600"
            }
          `}
          >

            <CalendarCheck size={20} />

            My Bookings

          </button>

        </nav>

        <div className="absolute bottom-5 w-full px-4">

          <button
            onClick={onLogout}
            className="w-full bg-red-500 hover:bg-red-600 py-3 rounded-xl flex items-center justify-center gap-2"
          >

            <LogOut size={18} />

            Logout

          </button>

        </div>

      </aside>

      {/* Main */}

      <div className="flex-1">

        {/* Header */}

        <header className="bg-white shadow-sm h-16 flex items-center justify-between px-6">

          <button
            className="lg:hidden"
            onClick={() =>
              setSidebarOpen(true)
            }
          >
            <Menu />
          </button>

          <h1 className="text-2xl font-bold text-slate-700">

            Cabin Management System

          </h1>

          <div className="text-slate-500 font-medium">

            Employee

          </div>

        </header>

        {/* Content */}

        <main className="p-6">

          {renderContent()}

        </main>

      </div>

    </div>
  );
}